﻿$(document).ready(function () {
    $('.jcarousel-skin-ameren').bind('loaded', function () {
        $(this).jcarousel({ scroll: 3 });
    });

    $('.jcarousel-skin-ameren').trigger('loaded');

});