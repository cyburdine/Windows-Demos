﻿var homepage = (function () {
    var $loginButton;
    var $userID;
    var $chkRememberMe;
    var loginHref;
    var isLoggedIn;
    var aeeUserId;
    var amerenLogoutUrl = 'http://www2.ameren.com/logout.aspx';
    var amerenLoginErrorUrl = 'https://www.ameren.com/login-error';
    
    //Public method
    function init() {
        bindElems();
        bindEvents();
    }

    //Private methods
    function bindElems() {
        $loginButton = $('#btnLogin');
        $userID = $('#UserID');
        $chkRememberMe = $('#RememberMe');

        aeeUserId = $userID.val();

        if (document.cookie.indexOf('aValid') == -1) {
            isLoggedIn = 'false';
        } else {
            isLoggedIn = 'true';
        }
    }

    function bindEvents() {
        //UserID blur (lost focus) action
        $userID.blur(function () {
            if ($userID.val() == "") {
                $chkRememberMe.prop("checked", false);
            }
            else if ($userID.val() != aeeUserId) {
                aeeUserId = $userID.val();
                $chkRememberMe.prop("checked", false);
            }
        });

        $loginButton.click(function (e) {
            e.preventDefault();

            var isRememberChecked = $chkRememberMe[0].checked;

            if (isLoggedIn != 'true') {
                Common.form.submit($('#loginForm'), "Authenticating...", function (data) { success(data); }, function (data) { fail(data); });
            }
            else { //User is Logged in, redirect them to logout page.
                window.location = amerenLogoutUrl;
            }
        });
    }
       
    function success(data) {
        namlogin.newPostToUrl(data.message);
    };

    function fail(data) {
        switch (data.status) {
            case 400:
                window.location = amerenLoginErrorUrl;
        }
    };

    function setLogoutUrl(url) {
        amerenLogoutUrl = url;
    };

    function setLoginErrorUrl(url) {
        amerenLoginErrorUrl = url;
    };

    return {
        init: init,
        setLogoutUrl: setLogoutUrl,
        setLoginErrorUrl: setLoginErrorUrl
    };

})();

