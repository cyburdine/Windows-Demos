﻿var loginlogout = (function () {

    var amerenLogoutUrl;
    var amerenLoginUrl;
    var amerenLoginButtonImage;
    var amerenLoginButtonImageBig;
    var amerenLogoutButtonImage;
    var isLoggedIn;
    var $userID; 
    var $password;

    //Public method
    function init(aLoginUrl, aLogoutUrl, loginImg, loginImgBig, logoutImg) {
        bindElems();
        
        amerenLoginUrl = aLoginUrl;
        amerenLogoutUrl = aLogoutUrl;
        amerenLoginButtonImage = loginImg;
        amerenLoginButtonImageBig = loginImgBig;
        amerenLogoutButtonImage = logoutImg;

        
        checkLoginStatus();
        //window.setInterval(function () { checkLoginStatus(); }, 3000);
        
       
    }

    //Private methods
    function bindElems() {       
        $userID = $('input[name$="UserID"]');
        $password = $('input[name$="Password"]');
        loginHref = $('.loginButton').attr('href');
    }

    function checkLoginStatus() {       
        var currentIsLoggedIn = isLoggedIn;
        if (document.cookie.indexOf('aValid') == -1) {
            isLoggedIn = 'false';
        } else {
            isLoggedIn = 'true';
        }

        if (currentIsLoggedIn != isLoggedIn)
            changeLoginStatus(loginHref);

        window.setTimeout(function () { checkLoginStatus(); }, 3000);
    }

    function changeLoginStatus(loginPost) {       
        var userID = $('input[name$="UserID"]');
        var pwd = $('input[name$="Password"]');

        if (isLoggedIn != 'true') {
            //Removed Red Log Out link code here.
            $('img[src*="MyAccountLogout.png"]').parent().attr('href', amerenLoginUrl);
            $('img[src*="MyAccountLogout.png"]').attr('src', amerenLoginButtonImageBig);
            $('#btnLogin').attr('src', amerenLoginButtonImage);
            $('#btnLogin').attr('style', 'margin: 3px 0 38px 0;display:block;margin-right:auto;margin-left:auto;');
            $('#btnLogin').attr('href', loginPost);
            $('#btnLogin').removeAttr('logout');
            userID.removeAttr('disabled');
            pwd.removeAttr('disabled');

        }
        else {
            //Removed Red Log Out link code here.
            $('img[src*="MyAccountLogin.png"]').parent().attr('href', amerenLogoutUrl);
            $('img[src*="MyAccountLogin.png"]').attr('src', amerenLogoutButtonImage);
            $('#btnLogin').attr('src', amerenLogoutButtonImage);
            $('#btnLogin').attr('style', 'margin: 3px 0 38px -8px;display:block;margin-right:auto;');
            $('#btnLogin').attr('href', amerenLogoutUrl);
            $('#btnLogin').attr('logout', 'logout');
            $(".loginInput").hide();
            $(".loginLabel").hide();
            $(".loginLink").hide();
            $("#loginTitle").hide();
        }

    }

    return {
       init: init     
    }

})();