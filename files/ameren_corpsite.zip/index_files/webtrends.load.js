// WebTrends SmartSource Data Collector Tag v10.4.1
// Copyright (c) 2014 Webtrends Inc.  All rights reserved.
// Tag Builder Version: 4.1.3.2
// Created: 2014.03.27

var wtodDCSID;

var docHost = window.location.hostname.toLowerCase();
// 'ameren.com' or 'www.ameren.com' or 'apps.ameren.com' or 'forms.ameren.com' or 'surveyforms.ameren.com' URLs to production Webtrends dcsid & domain
if (docHost.indexOf("ameren.com") == 0 ||
    docHost.indexOf("www.ameren.com") >= 0 ||
    docHost.indexOf("apps.ameren.com") >= 0 ||
    docHost.indexOf("forms.ameren.com") >= 0 ||
    docHost.indexOf("surveyforms.ameren.com") >= 0) {

		wtodDCSID = "dcs2226bh7o5uqtotv8bno3y4_7e3v";
}
// 'www2.ameren.com' URLs to production Webtrends dcsid & domain
else if (docHost.indexOf("www2.ameren.com") >= 0) {
    wtodDCSID = "dcs22238ufi5gb88zz7oq4a9j_5j1e";
}
// 'localhost' or 'ecust'URLs to production Webtrends dcsid & domain
else if ((docHost.indexOf("localhost") >= 0) || (docHost.indexOf("ecust") >= 0)) {
    wtodDCSID = "dcs222jowwewrdmlgwr0ra8hm_2s5q";
}
// All other URLs to internal Webtrends dcsid & domain
else {
    wtodDCSID = "dcs222ki9ywrqczs8dypto6s2_6o5e";
}

window.webtrendsAsyncInit=function(){
    var dcs=new Webtrends.dcs().init({
        dcsid: wtodDCSID,
        domain: "statse.webtrendslive.com",
        timezone: -6,
        i18n: false,
        offsite: false,
        download: true,
        downloadtypes: "xls,doc,pdf,txt,csv,zip,docx,xlsx,rar,gzip",
        anchor: false,
        javascript: true,
        onsitedoms: new RegExp("ameren.com"),
        fpcdom: ".ameren.com",
        plugins: {
            oss: { src: "//www.ameren.com/SiteJS/Plugins/webtrends.oss.js" },
            link_t: { src: "//www.ameren.com/SiteJS/Plugins/webtrends.link_t.js" },
            replicate: {
                src: "//www.ameren.com/SiteJS/Plugins/webtrends.replicate.js",
                callbackTimeout: 200
            }
        }
	}).track();
};
(function(){
    var s=document.createElement("script"); s.async=true; s.src="//www.ameren.com/SiteJS/Plugins/webtrends.js";
    var s2=document.getElementsByTagName("script")[0]; s2.parentNode.insertBefore(s,s2);
}());
