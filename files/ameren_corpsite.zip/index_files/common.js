﻿var Common = Common || {};

Common.global = (function () {
    var amerenHostName = "";
    var amerenCdn = "";
    var amerenImageRoot = "";
    var $imageCheckbox;
    var $goBackButton;

    //Public method
    function init() {
        bindElems();
        bindEvents();
    }

    //Private methods
    function bindElems() {
        $imageCheckbox = $('.imageCheckbox');
        $goBackButton = $('.goBackButton');
    }

    function bindEvents() {
        $($imageCheckbox).on("keypress", (function (e) {
            handleCheckboxEvent(e);
        }));

        $goBackButton.on("click", (function (e) {
            window.history.go(-1);
            return false;
        }));
    }

    function handleCheckboxEvent(e) {
        if (e.keyCode === 32) {  // If spacebar fired the event                
            e.preventDefault();
            $(e.target).trigger("click");
        }
    }

    return {
        amerenHostName: amerenHostName,
        amerenCdn: amerenCdn,
        amerenImageRoot: amerenImageRoot,
        init: init
    }
})();

Common.form = (function () {
    'use strict';
    var VALIDATION_SELECTOR = '[data-valmsg-for="';
    var ERR_FLDS_CLASSNAME = 'input-validation-error';

    function submit(currentForm, message, done, fail, returnDataType) {

        if (currentForm.valid && !currentForm.valid()) {
            currentForm.validate().errorList[0].element.focus();
            return;
        }
        if (typeof (returnDataType) == 'undefined')
        {
            returnDataType = 'json';
        }
        if (!message || message == "")
            message = "Loading...";

        var $form = currentForm;
        var $errMsgs = $('.field-validation-valid');

        Common.validation.clearValidationErrors($form);

        Common.modal.create("Please wait", message, "None", function (btn, modalWindow) {
            $.ajax({
                cache: false,
                type: $form.prop('method'),
                url: $form.prop('action'),
                contentType: 'application/x-www-form-urlencoded',  //this is the default, specified to show intent
                data: $form.serialize(),
                dataType: returnDataType
            })
            .done(function (response) {
                if (typeof (done) == "undefined") {
                    if (response && response.length) {
                        window.location = response; //Default response will be a redirect URL
                    } else {
                        console.error('Redirect URL is undefined.');
                    }
                }
                else {
                    //custom done function
                    done(response);
                }
            })
            .fail(function (xhr) {
                if (!xhr || xhr.length) return;

                if (typeof (fail) == "undefined") {
                    var errors = "A system error occurred. " + (xhr.status ? xhr.status : "");
                    try {
                        errors = JSON.parse(xhr.responseText);                        
                    }
                    catch (e)
                    {
                        console.log((xhr.responseText ? xhr.responseText : ""));                       
                    }                   
                    Common.validation.setValidationErrors(errors);
                }
                else {
                    //custom fail function
                    fail(xhr);
                }
            })
            .always(function () {
                Common.modal.destroy(modalWindow);
				//var captureURL;
				//captureURL = window.location.pathname;
               /* try {

					if (TLT && TLT.isInitialized()) {
						TLT.logScreenviewLoad('captureURL');
						console.log('sent to Tealeaf from always');
					}
				}
                catch(err) {} */
            });
        }, false, 200);
    }

    function clearFormSelections(form, clearHiddens) {
        clearHiddens = clearHiddens || false;
        //var frm_elements = form.elements;
        var frm_elements = form.find('input', 'select');
        var i;
        for (i = 0; i < frm_elements.length; i++) {
            var field_type = frm_elements[i].type.toLowerCase();
            switch (field_type) {
                case "text":
                case "password":
                case "textarea":
                    frm_elements[i].value = "";
                    break;
                case "radio":
                case "checkbox":
                    if (frm_elements[i].checked) {
                        frm_elements[i].checked = false;
                    }
                    break;
                case "select-one":
                case "select-multi":
                    frm_elements[i].selectedIndex = -1;
                    break;
                default:
                    break;
            }

            if (field_type == "hidden") {
                if (clearHiddens) frm_elements[i].value = "";
            }
        }
    }
    function enableHiddenFieldValidation(form) {
        form.data('validator').settings.ignore = "";
    }

    return {
        submit: submit,
        clearFormSelections: clearFormSelections,
        enableHiddenFieldValidation: enableHiddenFieldValidation
    }
})();

Common.functions = (function () {
    padLeft = function (input, padCount, padCharacter) {
        var convertedString = input.toString();
        if (!padCharacter) { padCharacter = '0'; }
        while (convertedString.length < padCount)
            convertedString = padCharacter + convertedString;
        return convertedString;
    }

    function expandIfTargeted(accordionDivID, opCodes, confirmationCallBack) {
        var targetOperation = Common.functions.getUrlVars()['op'];
        if ($.inArray(targetOperation, opCodes) >= 0) {
            var accordionButton = $(accordionDivID + ' .accordionButton');
            if (confirmationCallBack && confirmationCallBack(targetOperation) == false) {
                return;
            }
            if (accordionButton.is(':visible')) {
                accordionButton.click();
            }
        }
    }

    function getUrlVars() {
        var vars = [], hash;
        var hashes = window.location.search.slice(window.location.search.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    }

 
    function endsWith(value, stringCheck) {
        var foundIt = (value.lastIndexOf(stringCheck) === value.length - stringCheck.length) > 0;
        return foundIt;
    }

    function parseMoneyStringToDecimal(value) {
        return value.substr(1).replace(',', '');
    }

    function isDefinedAndNotNull(obj){
        var isDefined = true;
        if (typeof (obj) === "undefined" || obj == null) {
            isDefined = false;
        }        
        return isDefined;
    }

    return {
        padLeft: padLeft,
        getUrlVars: getUrlVars,
        expandIfTargeted: expandIfTargeted,
        endsWith: endsWith,
        parseMoneyStringToDecimal: parseMoneyStringToDecimal,
        isDefinedAndNotNull : isDefinedAndNotNull
    }
})();

Common.modal = (function () {

    var MODALCOOKIENAME = "aeeSegCode";

    function create(title, message, buttons, callback, useCloseButton, modalWidth, addWarningMsgDiv, currentModalCookieKey) {
        //optional parameter that we can use to keep the progress dialog after the post incase we send them to another longloading page.
        // defaults to true, which will destroy the dialog once the ajax post has completed.
        var deleteSecondModal = $(".ui-dialog").length <= 0;
        var closeBtn = "";
        var checkboxHtml = "";

        //Cookie to prevent the modal from opening again if a user wants to opt out of it
        var amerenModalCookieName = "eCustModalCookie";

        //Set callback to empty if undefined or null
        if (!Common.functions.isDefinedAndNotNull(callback)) { callback = function () { } }

        if (currentModalCookieKey) {
            var dontShowModal = getCookie(amerenModalCookieName, currentModalCookieKey);
            if (dontShowModal === true)
                return;
            else
                checkboxHtml = "<div class='modal-check-container'><input type='checkbox' id='dontShowModal' class='dont-show-modal-check' /><span id='dontShowModalText' class='modal-title-input-text'>Don't show this again </span></div>";
        }

        if (buttons == null || buttons == undefined)
            buttons = "none";

        //Get ye olde timey html!
        if (useCloseButton == null || useCloseButton == undefined)
            useCloseButton = true;

        if (useCloseButton)
            closeBtn = '<img src="' + Common.global.amerenImageRoot + 'Buttons/alertCloseBtn.png" class="modal-close-button"/>';

        var modalDim = "<div class='ui-widget-overlay' />";
        var modalTitle = '<div class="modal-dialog-title"><span>' + title + '</span><div class="title-right">' + checkboxHtml + closeBtn + '</div></div>';
        var modalBody = '<div class="modal-dialog-body"><img class="saving" alt="" src="' + Common.global.amerenImageRoot + 'saving.gif"/>' + message + '</div>';

        var modalWarningMessage = "";
        if (addWarningMsgDiv)
            modalWarningMessage = "<div class='modal-msg'></div>";

        //Set up ye olde timey buttons!
        var buttonHtml = "";
        var buttonTemplate = "<img id='{0}' src='{1}' class='{2}'/>"
        var leftButton = "<img id='leftbtn' src='{0}' class='{1}'/>";
        var rightButton = "<img id='rightbtn' src='{0}' class='{1}'/>";
        var buttonUrl = "";
        var rightButtonAvailableForUse = true;
        var buttonList = "";
        if (buttons) {
            buttonList = buttons.split("|");
            for (var i = 0; i < buttonList.length; i++) {
                var buttonDetails = buttonList[i].split(":");
                var buttonType = buttonDetails[0].toLowerCase();

                if (buttonType === "text") {
                    buttonHtml += "<div id='linkWrapper' class='{0}'><a class='linkInDialog' href='javascript: void(0);' id='rightbtn'>"
                                  .replace("{0}", buttonDetails.length > 2 ? buttonDetails[3] : "modal-link-wrapper")
                                  + buttonDetails[1];
                    + "</a><span>.</span></div>";
                    rightButtonAvailableForUse = false;
                } else {
                    switch (buttonType) {
                        case "continue":
                            buttonUrl = Common.global.amerenImageRoot + "Buttons/Continue.png";
                            break;
                        case "save":
                            buttonUrl = Common.global.amerenImageRoot + "Buttons/Save.png";
                            break;
                        case "yes":
                            buttonUrl = Common.global.amerenImageRoot + "Buttons/Yes.png";
                            break;
                        case "start-now":
                            buttonUrl = Common.global.amerenImageRoot + "Buttons/StartNow.png";
                            break;
                        case "no":
                            buttonUrl = Common.global.amerenImageRoot + "Buttons/No.png";
                            break;
                        case "close":
                            buttonUrl = Common.global.amerenImageRoot + "Buttons/close.png";
                            break;
                        case "cancel":
                            buttonUrl = Common.global.amerenImageRoot + "Buttons/ai-Cancel.png";
                            break;
                        default:
                            buttonUrl = "";
                            break;
                    }
                    if (buttonUrl !== "") {
                        var hasClass = buttonDetails.length > 1;
                        var hasId = buttonDetails.length > 2;
                        if (i === 0 && !hasId) {
                            buttonHtml += leftButton.replace("{0}", buttonUrl)
                                .replace("{1}", hasClass ? buttonDetails[1] : "");
                        }
                        else if (i + 1 === buttonList.length && rightButtonAvailableForUse && !hasId)
                            buttonHtml += rightButton.replace("{0}", buttonUrl)
                                .replace("{1}", hasClass ? buttonDetails[1] : "");
                        else {
                            buttonHtml += buttonTemplate.replace("{0}", hasId ? buttonDetails[2] : buttonType + i)
                                .replace("{1}", buttonUrl).replace("{2}", hasClass ? buttonDetails[1] : buttonType);
                        }
                    }
                }
            }
        }

        var buttonRow = "<div class='modal-buttons'>" + buttonHtml + "</div>";
        //if buttons are present we want to show the original modal dialog that will allow these buttons...if no buttons are present show the new simplistic spinner icon
        var waitDialog;
        if (buttons.toLowerCase() !== 'none') {
            waitDialog = $(modalDim + '<div id="dialogContent" class="content modal-dialog-window">' + modalTitle + modalBody + modalWarningMessage + buttonRow + '</div>').appendTo('body');
        } else {
          waitDialog = $('<div id="loading-spinner" loading-spinner><div class="loading-container" modal-background><div class="icon"></div></div></div>').appendTo('body');
        }
        // added ID to waitDialog for spinner - more able to capture in Tealeaf
        if (modalWidth == undefined || modalWidth == "")
            modalWidth = 150;

        //Dialogin!
        $(waitDialog).dialog({
            minWidth: 180,
            width: modalWidth,
            modal: true,
            resizable: false,
            minHeight: 90,
            height: 'auto',
            closeOnEscape: false,
            dialogClass: 'no-close',
            open: function (event, ui) {
                $(".ui-widget-content").addClass('no-background');
                $(waitDialog).siblings('div.ui-dialog-titlebar').hide(); // hides the title bar so users can't close the dialog and click save again.            
            },
            beforeClose: function (event, ui) {
                var dontShowModalValue = $("#dontShowModal");
                if (dontShowModalValue.prop('checked') === true) {
                    appendCookieValue(amerenModalCookieName, currentModalCookieKey)
                }
            }
        });

        //Here be click events
        $("#dontShowModal").click(function () {
            destroy($(waitDialog));
        });

        $(".modal-dialog-title img").click(function () {
            destroy($(waitDialog));
        });

        $("#rightbtn").click(function () {
            callback("continue", waitDialog);
        });

        $("#leftbtn").click(function () {
            callback("cancel", waitDialog);
        });

        $("#startbtn").click(function () {
            destroy($(waitDialog));
        });

        if (buttonList.length > 2) {
            for (var i = 1; i < buttonList.length; i++) {
                if (i + 1 !== buttonList.length) {
                    $("#" + buttonList[i] + i).on("click", function () {
                        callback(buttonList[i], waitDialog);
                    });
                }
            }
        }

        if (buttons == 0) { callback("", waitDialog); }

        if (buttons.toLowerCase() === "none") { callback("", waitDialog); }

        var erroneousDiv = $(".ui-dialog")[0];
        $(erroneousDiv).remove();
        
        if (deleteSecondModal)
            $(".ui-dialog").nextAll().remove();

        return waitDialog;

    }

    function getCookie(cookieName, valueName) {
        var foundcookie = $.cookie(cookieName);
        if (foundcookie != null)
            if (foundcookie.indexOf(valueName) >= 0)
                return true;
        return false;
    }

    function appendCookieValue(cookieName, cookieValue) {
        var foundcookie = $.cookie(cookieName);
        var domain = (location.hostname.toLowerCase().indexOf('ameren.com') > -1) ? ".ameren.com" : location.hostname;
        if (foundcookie != null) {
            if (foundcookie.indexOf(cookieValue) < 0) {
                if (cookieName == MODALCOOKIENAME) {
                    $.cookie(cookieName, cookieValue, { expires: 182, path: '/', domain: domain });
                }
                else {
                    $.cookie(cookieName, foundcookie + ";" + cookieValue, { expires: 365, path: '/', domain: domain });
                }
            }
        }
        else {
            if (cookieName == MODALCOOKIENAME) {
                $.cookie(cookieName, cookieValue, { expires: 182, path: '/', domain: domain });
            }
            else {
                $.cookie(cookieName, cookieValue, { expires: 365, path: '/', domain: domain });
            }
        }
    }

    function destroy(dialog) {
        $(dialog).dialog().dialog("close");
        $(dialog).empty().dialog("destroy");
        $(dialog).parents(".ui-dialog").remove();
        $(dialog).remove();
        if ($(".ui-widget-overlay").length > 0) $(".ui-widget-overlay").remove();
        if ($('#dialogContent').length > 0) $('#dialogContent').remove();
        var delayMillis = 1500; //1.5 second
		var captureURL;
        captureURL = window.location.pathname;
		setTimeout(function(){  
      
		    try {
				if (TLT && TLT.isInitialized()) {
					TLT.logScreenviewLoad(captureURL);
					//console.log('sent screenview to Tealeaf');
				}
			}
            catch(err) {}
          }, delayMillis);

    }

    return {
        create: create,
        destroy: destroy
    }

})();

Common.ajax = (function () {

    function handleError(errorData, erroModalTitle, errorModalMessage) {
        var currentModal = $("#dialogContent");
        if (currentModal) {
            Common.modal.destroy(currentModal);
            $(".ui-widget-overlay").remove();

        }

        $.ajax({
            url: "/Error/LogAjaxError",
            type: "POST",
            data: { "error": (errorData || { responseText: "Error" }).responseText },
            dataType: "text",
            success: function (data) {
                Common.modal.create(erroModalTitle, errorModalMessage, "", function (id, modalRetry) {
                    Common.modal.destroy(modalRetry);
                }, true);
            }
        });
    }

    function refreshUserforAll() {
        var $form = $("form#refreshForm");
        Common.ajax.silentAjaxFormPost($form, function (resp) { /*ignore response*/ }, "jsonp") // using JSONP dataType for CORS support
    }

    function silentAjaxFormPost(form, done, dataType) {
        if (typeof (dataType) == 'undefined') {
            dataType = 'json';
        }
        var $form = $(form);
        $.ajax({
            cache: false,
            jsonpCallback: 'callback',
            type: $form.prop('method'),
            url: $form.prop('action'),
            contentType: 'application/x-www-form-urlencoded',  //this is the default, specified to show intent
            data: $form.serialize(),
            dataType: dataType
        })
          .done(function (response) {
              if (typeof (done) == "undefined") {
                  console.error('Result method  is undefined.');
              }
              else {
                  done(response);
              }
          })
          .fail(function (xhr) {
              if (!xhr || xhr.length) return;
              var errors = "A system error occurred.";
              try {
                  errors = JSON.parse(xhr.responseText);
              } catch (e) { /* JSON was not valid */ }

          })
    };

    return {
        handleError: handleError,
        silentAjaxFormPost: silentAjaxFormPost,
        refreshUserforAll: refreshUserforAll
    }

})();

Common.CSRF = (function () {

    var TOKENNAME = "__RequestVerificationToken";
    function token() { return $('input[name=' + TOKENNAME + ']').val(); };

    function init() {
        $.ajaxSetup({
            cache: false,
            beforeSend: function (xhr) {
                xhr.setRequestHeader(TOKENNAME, token());
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                switch (XMLHttpRequest.status) {
                    case 302: 
                        console.log("Page/Filter respose : Redirected");
                        window.location = XMLHttpRequest.responseJSON;
                        return;
                    case 400:
                        return;
                    case 403:
                        console.log("Login Issue : Forbidden");
                        window.location = XMLHttpRequest.responseJSON;
                        return;                    
                }

                Common.ajax.handleError(XMLHttpRequest.responseText, "Request Failed", "Request failed. Please try again.");
            }
        });
    }

    return {
        init: init
    }

})().init();

$(document).ready(function () {
    'use strict';
    Common.global.init();
});