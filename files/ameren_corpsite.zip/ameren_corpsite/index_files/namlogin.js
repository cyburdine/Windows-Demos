﻿var namlogin = (function () { 

function newPostToUrl(data)
{
    var params = $.parseJSON(data);
    var method = "post"; // Set method to post by default, if not specified.
    var path = "";
   
    var form = document.createElement("form");
    form.setAttribute("method", method);
      
    form.setAttribute("action", params["NAMURL"]);

    var targetField = document.createElement("input");
    var idField = document.createElement("input");
    var passwordField = document.createElement("input");
    var userIdField = document.createElement("input");

    targetField.setAttribute("type", "hidden");
    targetField.setAttribute("name", "target");
    targetField.setAttribute("value", params["Target"]);
    form.appendChild(targetField);

    idField.setAttribute("type", "hidden");
    idField.setAttribute("name", "id");
    idField.setAttribute("value", params["ID"]);
    form.appendChild(idField);

    passwordField.setAttribute("type", "hidden");
    passwordField.setAttribute("name", "Ecom_Password");
    passwordField.setAttribute("value", params["Password"]);
    form.appendChild(passwordField);

    userIdField.setAttribute("type", "hidden");
    userIdField.setAttribute("name", "Ecom_User_ID");
    userIdField.setAttribute("value", params["UserID"]);
    form.appendChild(userIdField);

    document.body.appendChild(form);

    form.submit();
}

    return {
        newPostToUrl: newPostToUrl
    };

})();
