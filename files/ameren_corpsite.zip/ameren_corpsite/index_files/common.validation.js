﻿var Common = Common || {};
Common.validation = (function () {
    'use strict';

    var VALIDATION_SELECTOR = '[data-valmsg-for="';
    var ERR_FLDS_CLASSNAME = 'input-validation-error';

    //"Constructor" logic. this does not wait for init() / document.ready
    registerGenericRegExMulti();
    registerMustBeTrue();
    registerDynamicRange();
    // Public methods
    function init() {
        // This overrides JQV's default behavior of not validating unmodified required fields
        $(document).on('blur', '[data-val=true]', function () {
            setTimeout(Common.validation.validateField, 200, this);
        });
    }
    function validateField(elem) {
        $(elem).valid();
    }


    // Hooks jqv errorPlacement event to specified element and xrefMethodUI req tracking map.
    // ALL the validation rules for the element are tested so that those in the UI are individually tracked
    function hookValReqChks(testedElem, xrefMethodUI) {
        $(function () {
            var opts = $.data(testedElem.closest('form')[0], 'validator').settings;
            var prevErrorPlacement = opts.errorPlacement;

            // short circuits jqv lazy validation for requirements checklist
            testedElem.on('focus', function () {
                $(this).valid();
            });

            opts.errorPlacement = function (error, triggerElem) {
                if (triggerElem.is(testedElem)) {
                    var resultMap = getValidationResultMap(triggerElem);
                    handleChklistReqUI(resultMap, xrefMethodUI)
                }
                prevErrorPlacement(error, triggerElem);
            };
        });
    }

    // Dynamically loaded partials views require rebind because they are after the main page is is already bound. 
    function reBindValidation(form) {
        form.removeData('validator');
        form.removeData('unobtrusiveValidation');
        $.validator.unobtrusive.parse(form);

        //This overrides JQV's default behavior of not validating unmodified required fields
    }

    function clearValidationErrors(context) {
        // clear error messages
        context.find('[data-valmsg-replace]')
            .removeClass('field-validation-error')
            .addClass('field-validation-valid')
            .empty();

        // reset inputs
        context.find('.input-validation-error')
            .removeClass('input-validation-error')
            .addClass('valid');
    }

    function setValidationErrors(errors /*array*/) {
        if ($.isArray(errors)) {
            for (var i = 0; i < errors.length; i++) {
                $(VALIDATION_SELECTOR + errors[i].Name + '"]')
                    .attr('data-val-server', 'true')
                    .text(errors[i].Message).show();
                $('#' + errors[i].Name).addClass(ERR_FLDS_CLASSNAME);

            }
        } else {
            if (typeof (errors) == "object") {
                $('#errorMsg').show().text(errors.message);
            }
            else {
                $('#errorMsg').show().text(errors);
            }
        }
    }

    // Private methods
    function handleChklistReqUI(results, xrefMethodUI) {
        for (var i = 0, len = results.length; i < len; i++) {
            var selector = xrefMethodUI[results[i].method]
            if (selector) {
                updateRequirementStatus.apply(this, [$(selector), results[i].isValid]);
            }
        }
    }

    // Toggle the checklist marks
    function updateRequirementStatus(element, isValid) {
        if (isValid) {
            element.removeClass('invalid').addClass('valid');
        } else {
            element.removeClass('valid').addClass('invalid');
        }
    }

    // Register generic client side regexmulti validatation
    function registerGenericRegExMulti() {

        // Note: these method names are coupled w/ methodName in RegExCustomValidationClientAttributes.cs
        var genericMethods = ['regexmultia', 'regexmultib', 'regexmultic', 'regexmultid'];

        function registerVal(methodName) {
            // Hook custom method and unobstusive adapter
            $.validator.addMethod(methodName, function (value, element, params) {
                var re = RegExp(params.regex);
                var result = re.test(value);
                if (params.invertresult) {
                    return !result;
                }
                return result;
            });
            $.validator.unobtrusive.adapters.add(methodName, ['regex', 'invertresult'], function (options) {
                options.rules[methodName] = {
                    regex: options.params.regex,
                    invertresult: options.params.invertresult == 'true'  // passed to us as a string
                }
                options.messages[methodName] = options.message;
            });
        }
        // Hook custom method and unobstrusive adapter for each regexmulti
        for (var i = 0, len = genericMethods.length; i < len; i++) {
            var methodName = genericMethods[i];
            registerVal(methodName);
        }
    }

    // tests *ALL* validation rules for an element
    // returns array of the tested rules and the validation result for each
    function getValidationResultMap(element) {
        var rules = $(element).rules();
        var value = element.val();
        var results = [];

        // Call all methods on passed element (don't stop at error)
        for (var method in rules) {
            var rule = { method: method, parameters: rules[method], isValid: false };

            // Would love to be able to just do this. Good luck
            // TODO: research jq $.proxy. It may do the trick here.
            //result = $.validator.methods[method].call(this, val, element, rule.parameters);

            if (rule.method == 'required') {
                if (value) rule.isValid = true;
            }
            if (rule.method == 'rangelength') {
                var len = value.length;
                if (len >= rule.parameters[0] && len <= rule.parameters[1]) rule.isValid = true;
            }
            if (rule.method.substr(0, 5) == 'regex') {
                // TODO: refactor this code.
                if (rule.parameters.regex) {
                    var re = RegExp(rule.parameters.regex);
                    var invertresult = rule.parameters.invertresult;
                } else {
                    var re = RegExp(rule.parameters);
                    var invertresult = false;
                }
                var result = re.test(value);
                if (invertresult) {
                    rule.isValid = !result
                } else {
                    rule.isValid = result
                }
            }
            // ** Add more conditions for missing standard validations and custom user functions here ***
            results.push(rule);
        }
        return results;
    }


    $.validator.addMethod('requiredif',
        function (value, element, parameters) {
            var id = '#' + parameters['dependentproperty'];

            // get the target value
            var targetvalue = parameters['targetvalue'];
            targetvalue = (targetvalue == null ? '' : targetvalue).toString();

            // get the actual value of the target control
            // note - this probably needs to cater for more control types, e.g. radios
            var control = $(id);
            var controltype = control.attr('type');
            if (controltype === 'checkbox' || controltype === 'radio') {
                var actualvalue = $("input:" + controltype + "[name='" + parameters['dependentproperty'] + "']:checked").val();
                if (typeof (actualvalue) == 'undefined') {
                    actualvalue = control.is(':checked').toString();
                }
            }
            else {
                var actualvalue = control.val();
            }
            // if the condition is true, reuse the existing required field validator functionality
            var values = targetvalue.split(';');
            for (var i = 0; i < values.length; i++) {
                if (values[i] === actualvalue) {
                    return $.validator.methods.required.call(this, value, element, parameters);
                }
            }


            return true;
        }
    );

    $.validator.unobtrusive.adapters.add(
        'requiredif',
        ['dependentproperty', 'targetvalue'],
        function (options) {
            options.rules['requiredif'] = {
                dependentproperty: options.params['dependentproperty'],
                targetvalue: options.params['targetvalue']
            };
            options.messages['requiredif'] = options.message;
        });

    function registerMustBeTrue() {
        $.validator.addMethod("mustbetrue", function (value, element, param) {
            return element.checked;
        });
        $.validator.unobtrusive.adapters.addBool("mustbetrue");
    }

    function registerDynamicRange() {
        $.validator.unobtrusive.adapters.add('dynamicrange', ['minvalueproperty', 'maxvalueproperty'],
        function (options) {
            options.rules['dynamicrange'] = options.params;
            if (options.message != null) {
                $.validator.messages.dynamicrange = options.message;
            }
        });

        $.validator.addMethod('dynamicrange', function (value, element, params) {
            var minValue = parseInt($('input[name="' + params.minvalueproperty + '"]').val(), 10);
            var maxValue = parseInt($('input[name="' + params.maxvalueproperty + '"]').val(), 10);
            var currentValue = parseInt(value, 10);
            if (isNaN(minValue) || isNaN(maxValue) || isNaN(currentValue) || minValue > currentValue || currentValue > maxValue) {
                var message = $(element).attr('data-val-dynamicrange');
                $.validator.messages.dynamicrange = $.validator.format(message, minValue, maxValue);
                return false;
            }
            return true;
        }, '');
    }

    return {
        init: init,
        hookValReqChks: hookValReqChks,
        reBindValidation: reBindValidation,
        validateField: validateField,
        clearValidationErrors: clearValidationErrors,
        setValidationErrors: setValidationErrors
    }
})()

$(document).ready(function () {
    'use strict';
    Common.validation.init();
});