if (typeof(Webtrends.dcss.dcsobj_0.dcsGetIdCallback)=="function"){
Webtrends.dcss.dcsobj_0.dcsGetIdCallback({"gWtId":"","gTempWtId":"0377e291-4ef8-4569-997b-628234b02980","gWtAccountRollup":""});
}
