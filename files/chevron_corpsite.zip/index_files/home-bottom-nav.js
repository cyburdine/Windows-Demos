﻿(function (w, d, $) {
    $(document).ready(function () {
        //Used on facts-bar and col-tiles to keep same height
        $(".home-bottom-nav .col").matchHeight({
            byRow: true
        });
    });
})(window, document, jQuery);