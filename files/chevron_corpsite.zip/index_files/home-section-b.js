﻿(function (w, d, $) {
    $(document).ready(function () {
        function homeSectionBAdjust() {
            $(".home.section-b").each(function () {
                //$(w).width(); does not return the viewport width as related to the bootstrap breakpoints (as it excludes the the width of the scrollbars. The breakpoints include the total viewport width
                var windowWidth = window.innerWidth,
                    $colMd8 = $(this).find(".col-md-8"),
                    colMd8Width = $colMd8.width(),
                    $colMd4 = $(this).find(".col-md-4"),
                    movedClass = "moved-small";
                $colMd4.css("height", "auto");
                //Set Card height/width (square) and Promo height
                var itemSquareSize = (colMd8Width - 30) / 2,
                    promoHeight = itemSquareSize;
                //When In the News is taller than second column, stretch promo height
                if (windowWidth >= 992) {
                    //Move In the News if resizing from small or xs
                    if ($colMd4.hasClass(movedClass)) {
                        $colMd8.insertAfter($colMd4);
                        $colMd4.removeClass(movedClass);
                    }
                    if ($colMd4.height() > (promoHeight + itemSquareSize + 30)) {
                        promoHeight = $colMd4.height() - itemSquareSize - 30;
                    } else {
                        $colMd4.css("height", (promoHeight + itemSquareSize + 30) + "px");
                    }
                } else if (windowWidth < 768) {
                    itemSquareSize = colMd8Width;
                    promoHeight = itemSquareSize;
                    //Move In the News if resizing to xs
                    $colMd4.css("height", "auto").insertAfter($colMd8).addClass(movedClass);
                } else {
                    //Move In the News if resizing to small
                    $colMd4.insertAfter($colMd8).addClass(movedClass);
                }
                $(this).find(".home-cards .item").css("height", itemSquareSize + "px").css("width", itemSquareSize + "px");
                $(this).find(".home-promo .promo-tiles, .home-promo .promo-tiles .background, .home-promo .promo-tiles .background .promo-content").css("height", promoHeight + "px");

                $(this).find(".home-cards .flip-card").each(function (index) {
                    $(this).find("h3").css({ "font-size": ($(this).width() / 14) + 'px' });
                    $(this).find("h4").css({ "font-size": ($(this).width() / 18) + 'px' });
                    $(this).find(".card-bottom.tags").css({ "font-size": (($(this).width() / 18) > 16 ? 16 : ($(this).width() / 18)) + 'px' });
                });
            });
        }
        $(document).ready(function () {
            homeSectionBAdjust();
            $(w).resize(function () {
                homeSectionBAdjust();
            });
            //keep cols same height
            //$(".home.section-b .match-height").matchHeight({
            //    byRow: true
            //});
        });
    });
})(window, document, jQuery);